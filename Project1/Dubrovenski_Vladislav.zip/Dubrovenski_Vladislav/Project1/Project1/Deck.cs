﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    /// <summary>
    /// Entity/Control Class
    /// </summary>
    class Deck
    {
        /// <summary>
        /// deck of the cards
        /// </summary>
        private Card[] _deck = new Card[52];
        /// <summary>
        /// this holds the index of the top card in the deck
        /// </summary>
        private int _topIndex = -1;

        /// <summary>
        /// constructor for the deck
        /// </summary>
        public Deck()
        {
            int numberOfSuits = 4;// 0 to 3
            int numberOfRanks = 15; // 1-14
            int numberOfCards = 52;
            _topIndex++; //adding cards
            while (_topIndex < numberOfCards)
            {
                for (int suit = 0; suit < numberOfSuits; suit++)
                {
                    for (int rank = 2; rank < numberOfRanks; rank++)
                    {           
                        _deck[_topIndex++] = new Card(rank, (CardSuit)suit);
                    }
                }
            }
            _topIndex--;//making top index 51, as it suppose to be
        }
        /// <summary>
        /// Draws the top card
        /// </summary>
        /// <returns></returns>
        public Card Draw()
        {            
            Card c = _deck[_topIndex];
            _deck[_topIndex] = null;
            _topIndex--;
            return c;
        }
        /// <summary>
        /// Shuffle algorithm taken from Knuth
        /// </summary>
        public void Shuffle()
        {
            System.Random random = new System.Random();
            for (int i = 0; i < _deck.Length; i++)
            {
                int j = random.Next(i, _deck.Length); // Don't select from the entire array on subsequent loops
                Card temp = _deck[i];
                _deck[i] = _deck[j];
                _deck[j] = temp;
            }
        }
        /// <summary>
        /// return the card to the deck
        /// </summary>
        /// <param name="card"></param>
        public void ReturnCard(Card card)
        {
            _deck[++_topIndex] = card;
        }
    }
}
